<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="automne" tilewidth="16" tileheight="16" tilecount="540" columns="30">
 <image source="Automne.png" trans="000000" width="480" height="288"/>
</tileset>
